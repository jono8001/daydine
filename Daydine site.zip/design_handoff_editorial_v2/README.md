# Handoff: DayDine Editorial Redesign (v2)

**For:** Claude Code, working in `jono8001/daydine`
**From:** Design work done in a sibling Claude project
**Fidelity:** **High-fidelity.** The HTML files in this bundle are the pixel-level visual target. Recreate them in the existing static-HTML repo using the repo's conventions (plain HTML, no build step, shared `assets/` CSS). Do not ship the JSX or the Babel-in-browser scaffolding.

---

## 1. Overview

DayDine today ships as static HTML with a "porcelain/graphite/burnished gold" design system (`assets/daydine.css`). This handoff replaces that visual direction with an **editorial, broadsheet-newspaper register** — cream paper, italic Newsreader serif headlines, mono kickers, thin ruled lines, big ranked numerals — across three core pages. The scoring model, data pipeline, and page taxonomy are **unchanged**; only the visual system, copy register, and a handful of page concepts change.

### What's in this bundle

- `Daydine Home.html` — editorial front door (replaces `index.html`)
- `Daydine.html` — multi-variant ranking page (replaces `rankings.html`)
- `Daydine For Restaurants.html` — operator page (replaces `for-restaurants.html` + `pricing.html` + `reports.html` merged)
- Supporting CSS: `home.css`, `home-modules.css`, `operator.css`, `styles.css`, `variants.css`
- JSX scaffolding: `app.jsx`, `data.js`, `drawers.jsx`, `shared.jsx`, `variant-*.jsx` — **reference only**, do not port as React

### What this bundle does NOT cover (you will need to design or retain existing versions)

- `search.html` — UK establishment search with Leaflet map (big page, retain existing or redesign in this system)
- `methodology.html` — retain existing content, restyle in new system
- `sample.html` — sample report viewer
- `rankings/[slug].html` — city-level leaderboard page (the HOME page shows city teasers; clicking through needs a full page)
- `404.html`
- Editorial profile page for a ranked restaurant (does not exist today; may be the right next artefact)

---

## 2. Critical: Content is placeholder

**The mockups use London/Paris/Tokyo, 31 critics, "Spring 2026 issue," £280/£99 pricing, and driver names like "Wine Programme."**

**Replace ALL of that with DayDine's real model:**

| Mockup placeholder | Real DayDine |
|---|---|
| Cities (London, Paris, Tokyo, Copenhagen, NYC, LA) | UK Local Authority areas. Live: **Stratford-upon-Avon**. Pipeline: **Warwick, Birmingham, Oxford, Bath, Edinburgh** (from `assets/rankings/index.json`) |
| "The Spring 2026 issue," quarterly editorial rhythm | Continuous data pipeline, `last_updated` date from JSON |
| 31 anonymous critics | No critics. RCS V4 is pure data model |
| Composite score out of 100 (e.g. 92.4) | **`rcs_final` 0–10** (e.g. 9.837) |
| Drivers: critic index, wine programme, service notes, reservation velocity, room consistency | **RCS V4 three-component score**: Trust & Compliance (40%, FSA/FHRS), Customer Validation (45%, Bayesian-shrunk Google/TripAdvisor/OpenTable ratings), Commercial Readiness (15%, customer-path signals). Plus capped Michelin/AA distinction modifier and Companies House penalties |
| Bands: "Michelin-leaning", "Ambitious neighbourhood" etc. | **`rcs_band`**: Excellent, Good, etc. + `band_class`, `convergence` (converged/neutral/diverged), `movement` + `movement_delta` |
| Top-20 lists, editorially curated | **Top-10 featured + "others" count** (e.g. Stratford has 190 venues, top-10 shown, 180 others). Four-class confidence gating: Rankable-A / Rankable-B / Directional-C / Profile-only-D |
| "The Auberge, Fitzrovia" composite | Use real venues from `assets/rankings/stratford-on-avon.json`: Arrow Mill, The Fox Inn, Shakespaw Cat Cafe, Gilks' Garage Cafe, Oxheart, etc. |
| £280 one-off / £99/mo | **£49 one-off / £39/mo** |
| "28-page quarterly report" | "Position & Competitor Report" (see `quarterly_report_spec.md` in repo for true scope) |
| "Companies House verification" on preview | This is already right — keep it |
| "R. Halliday, Editor / F. Okorie, Head of Data" signatures | Replace with real signatories, or remove |
| "Critics ate with you in Q1" | Remove entirely — DayDine has no critic programme |
| Reservation velocity, repeat-visit rate | Replace with real RCS V4 signals — Google rating deltas, TripAdvisor coverage, FSA inspection date, convergence flag changes |

**Rule of thumb:** if a piece of copy implies an editorial/critic operation, rewrite it for a data-driven RCS operation. Keep the tone (calm, authoritative, broadsheet), change the substance.

---

## 3. Design Tokens — drop-in replacements for `assets/daydine.css`

These are the tokens I actually used. Add them to a `:root {}` in `assets/daydine.css`, replacing the porcelain/graphite/burnished-gold set.

```css
:root {
  /* Surfaces */
  --bg:           #f5ede0;  /* cream paper, primary background */
  --bg-2:         #f0e6d3;  /* slightly deeper cream, card backs */
  --bg-3:         #ebe0ca;  /* deepest cream, for wells/insets */
  --sel:          #ead9b3;  /* selection/highlight row */

  /* Ink */
  --ink:          #2a1d12;  /* near-black brown, body text and primary */
  --ink-2:        #4a3a28;  /* secondary text */
  --ink-dim:      #7a6a55;  /* tertiary / metadata */

  /* Rules */
  --rule:         #d8c9ae;  /* standard hairline */
  --rule-strong:  #bfae8f;  /* stronger divider */

  /* Accents */
  --accent:       #b77a3a;  /* paprika, CTA + kicker highlight */
  --accent-2:     #8a4a1a;  /* deeper burnt sienna, italic emphasis */
  --candle:       #d4a86a;  /* warm candle light — dark-mode accent */

  /* Status */
  --up:           #5a7a3a;  /* olive green, rank up */
  --down:         #a04028;  /* brick red, rank down */

  /* Type */
  --serif: 'Newsreader', Georgia, 'Times New Roman', serif;
  --sans:  'Inter', system-ui, -apple-system, sans-serif;
  --mono:  'JetBrains Mono', 'SF Mono', Consolas, monospace;
}
```

**Google Fonts import** (add to each page's `<head>`):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Inter:wght@400;500;600&family=Newsreader:ital,wght@0,400;0,500;0,600;1,400;1,500&display=swap" rel="stylesheet">
```

### Type scale (actually used)

| Use | Family | Size | Weight | Line-height | Letter-spacing |
|---|---|---|---|---|---|
| Hero headline | Newsreader | clamp(40px, 5vw, 68px) | 500 | 1.08 | -0.025em |
| Section headline | Newsreader | 40–44px | 500 | 1.05 | -0.02em |
| Rank numeral (big) | Newsreader | 82–92px | 500 | 0.9 | -0.04em, tabular-nums |
| Restaurant name (ranking row) | Newsreader | 20–22px | 500 | 1.15 | -0.01em |
| Body prose | Newsreader | 15–20px | 400 | 1.5–1.6 | 0 |
| Kicker / eyebrow | JetBrains Mono | 10–11px | 400 | 1 | 0.20–0.22em, UPPERCASE |
| Table / metadata | JetBrains Mono | 10–12px | 400 | 1.5 | 0.10–0.15em, UPPERCASE |
| Button / UI | Inter | 13–14px | 500 | 1 | 0.01em |

**Italic emphasis uses Newsreader Italic and is always coloured `--accent-2`.** Never italicise in mono.

### Spacing & rules
- Section vertical padding: `64–96px`
- Page max-width: `1240px`
- Gutters: `32px` desktop, `20px` mobile
- Hairlines: `1px solid var(--rule)`
- Strong dividers: `1px solid var(--rule-strong)` or `2px solid var(--ink)` (section breaks)
- Radii: `2–3px` only. **No rounded corners larger than 3px anywhere.**

### Button (`.btn`) — critical, the whole site depends on it
```css
.btn {
  font-family: var(--sans); font-size: 14px;
  padding: 12px 20px; border-radius: 2px;
  background: var(--bg-2); color: var(--ink);
  border: 1px solid var(--rule-strong);
  text-decoration: none; display: inline-block;
  letter-spacing: 0.01em; cursor: pointer;
}
.btn:hover { background: var(--ink); color: var(--bg); border-color: var(--ink); }
.btn-primary { background: var(--ink); color: var(--bg); border-color: var(--ink); }
.btn-primary:hover { background: var(--accent); border-color: var(--accent); color: #fff; }
```

---

## 4. Page Specs

### 4.1 Home (`index.html`)

**Reference file:** `Daydine Home.html`

**Purpose:** Front door. Explain what DayDine is, show current live markets, tease top restaurants, surface methodology cred, drive to the market list.

**Sections, top to bottom:**
1. **Masthead** — wordmark "Day*dine*" (italic "dine" in `--accent-2`), issue stamp ("STRATFORD-UPON-AVON · LIVE" or dynamic), nav: Home / Markets / Methodology / For Restaurants
2. **Sub-strip** (thin strip under masthead) — 3 short facts separated by ·. E.g. "264,791 UK establishments tracked · RCS V4 — data-driven, no critics · Last updated {last_updated}"
3. **Hero** — two-column: large italic serif headline + lede on left ("A data-driven ranking of where to eat in Britain"), a stylised "this week" instrument card on right (no photo). Show live market + next pipeline markets
4. **Markets grid** — cards for each live market. Pull from `assets/rankings/index.json`. Each card: city name (big serif), region, venue count, top score, "See the list →". Pipeline markets shown as greyed-out cards with "Validating" / "Requested" tags
5. **Top movers** — compact ranked list, 5 rows. Pull top 5 by largest `movement_delta` across all markets, or just top 5 from Stratford. Each row: rank, name, postcode, category, rcs_final, movement arrow
6. **Picks strip** — editorial module with 3–4 restaurant cards picked by `rcs_band === 'Excellent'` with `convergence === 'converged'`
7. **Trust strip** — methodology pillars in 3 columns: Trust & Compliance · Customer Validation · Commercial Readiness. Each with a short paragraph pulled from the methodology spec
8. **Journal / recent updates** — list of recent pipeline/methodology changes (pull from a JSON feed or hand-curate)
9. **Newsletter signup** — single email field, editorial wrap-around copy
10. **Footer** — 4-column: About / Read / Operators / Legal

**Data bindings:**
- Markets grid: `assets/rankings/index.json` → `.available[]` and `.pipeline[]`
- Top movers: `assets/rankings/stratford-on-avon.json` → `.venues[]` (sort by `Math.abs(movement_delta)` desc)
- Picks: same file, filter `rcs_band === 'Excellent' && convergence === 'converged'`

### 4.2 Rankings (`rankings.html`)

**Reference file:** `Daydine.html`

**Purpose:** The ranked list. This is the core artefact.

**Only one variant in production** — my project showed 3 toggleable variants (Warm/Editorial/Dusk) as a designer's exploration. **For shipping, pick ONE.** Recommended: **"01 · Warm"** (cream paper, paprika accent) — it matches the home page and is the most restrained.

**Structure:**
1. Masthead (same as home)
2. Sub-strip: market name + total venues + last updated + filter/sort summary
3. Filter bar: category (Restaurant/Pub/Cafe/Hotel), band (Excellent/Good/…), sort (rank ↑ / rcs_final ↓ / movement), search by name/postcode
4. **Ranked list** — numbered rows. Each row:
   - **Rank** (big serif numeral, tabular)
   - **Name** (big italic-capable serif)
   - **Postcode · Category** (mono, dim)
   - **RCS score** (big tabular numeral, `rcs_final` to 2dp)
   - **Band pill** (`rcs_band`, colour-coded by `band_class`)
   - **Convergence indicator** (converged ✓ / neutral · / diverged ⚠)
   - **Movement arrow** (▲/▼/— with `movement_delta`)
5. Methodology footer block: link to full methodology, confidence class explainer
6. "Others" collapsed section: rows 11–N in a denser, smaller table
7. Footer

**Data bindings:** `assets/rankings/[slug].json` for the city the user is viewing. Slug comes from URL.

**Per-restaurant detail:** on click, either navigate to `/rankings/[market]/[postcode-slug]` OR open a drawer (mockup shows a drawer). For v1, link to a future detail page; stub it.

### 4.3 For Restaurants (`for-restaurants.html`)

**Reference file:** `Daydine For Restaurants.html`

**Purpose:** Operator page. Merges what is currently `for-restaurants.html`, `pricing.html`, and `reports.html` into a single editorial page.

**Sections:**
1. Masthead + sub-strip
2. **Hero** — "See exactly *why* you're ranked where you are." + lede. Left column text, right column a live "instrument" card showing the reader's (imagined) current standing
3. **Preview your rank** — two-panel form: left = Companies House number + role + email form, right = free preview showing rank + 4-quarter (or 4-update) trend line, with a "locked" interpretation panel explaining what the paid report adds. **Fits DayDine perfectly**: only the number is free, the *why* is paid
4. **What's inside the report** — 6 editorial panels in a 3×2 grid. Rewrite each against your real report contents (see `quarterly_report_spec.md`)
5. **Sample report** — "The Auberge, Fitzrovia" excerpt page. **Replace with a real anonymised sample** from your actual reports, or use one of the Stratford venues with permission. Shows: rank, drivers (bar chart), peer cohort table, drivers memo quote
6. **Two products (pricing)** — broadsheet two-column layout. Single Report (£49) + Subscription (£39/mo). Include bullets, CTA. Portfolio terms as a classified-style footer line below
7. **Independence guarantee** — full-bleed dark-ink section with centred italic pull-quote ("A restaurant can pay us to *understand* its ranking. A restaurant can *never* pay us to change it."), 3-column methodology detail, signed. **This is the emotional climax of the page.** Keep it.
8. **Roadmap** — public product roadmap. Rewrite against your real plan (live markets upcoming: Warwick, Birmingham, Oxford, Bath, Edinburgh)
9. **FAQ** — operator-facing. Answers should reference RCS V4, not critics
10. Final CTA + footer

**Pricing numbers:** £49 one-off, £39/mo (from README). Not £280/£99.

### 4.4 Pages to retain or design separately

- `methodology.html` — content is fine, restyle with new tokens + Newsreader headlines, keep all technical content
- `search.html` — 264K-establishment search + Leaflet. Out of scope for this redesign pass. Restyle chrome (nav, footer, filter bar) to match new tokens; leave the map + result list alone
- `sample.html` — restyle in new system; keep PDF viewer functionality
- `rankings/[slug].html` — treat as an instance of `rankings.html` pointed at that city's JSON
- `pricing.html` and `reports.html` — **delete**, their content now lives inside `for-restaurants.html`. Add 301 redirects in `vercel.json`
- `404.html` — restyle

---

## 5. Interactions & Behavior

- **No heavy framework.** Use plain HTML + the existing `assets/daydine.js` pattern. If you need a small behaviour (filter, toggle), write it inline or add to `daydine.js`
- **Newsreader italic emphasis** — use `<em>` on headlines where the mockup shows italic (always coloured `--accent-2`)
- **Button hover** — background flips to `--ink`, text to `--bg`. See `.btn` rule above
- **Ranked table hover** — subtle row highlight using `--sel`
- **Filter bar** — instant client-side filter of the venue list. No network round-trip; all data is already in the JSON

### Responsive
- Desktop-first, tested at 1240px and 924px
- Mobile breakpoint at **1000px**: grids collapse to single column, two-column hero stacks
- Sub-mobile at **640px**: nav becomes hamburger (use existing `daydine.js` hamburger pattern)
- Ranked table rows collapse to stacked cards below 760px (retain existing DayDine pattern)

---

## 6. State Management

Static HTML only. The ranking pages read JSON at load and filter in-memory. No client state persists across pages. Preserve any existing DayDine patterns (`daydine.js` nav) rather than reinventing.

---

## 7. Migration Sequence (for Claude Code)

Do this in a branch named `redesign/editorial-v2`.

### Phase 1 — Design system
1. Replace `assets/daydine.css` tokens with the `:root` block from §3 above
2. Add the Google Fonts import to a shared partial (or to each page `<head>`)
3. Add the `.btn` / `.btn-primary` rules
4. Sanity-check: view any existing page. Buttons, links, body should already look different. Fix anything clearly broken before moving on

### Phase 2 — Home
1. Rewrite `index.html` using `Daydine Home.html` as visual target
2. Bind the markets grid to `assets/rankings/index.json`
3. Bind top movers + picks to `assets/rankings/stratford-on-avon.json`
4. Remove all "London/Paris/Tokyo/31 critics/Spring 2026" copy; replace with DayDine-accurate prose
5. Deploy to Vercel preview

### Phase 3 — Rankings
1. Rewrite `rankings.html` using `Daydine.html` as visual target (pick variant "01 · Warm" only)
2. Bind to `assets/rankings/[slug].json` (infer slug from URL)
3. Wire filter bar to real categories from the data
4. Restyle `rankings/stratford-on-avon.html` — this is currently a hand-written page, replace with the shared template
5. Preserve RCS bands, convergence indicators, movement — these are product features, don't lose them

### Phase 4 — For Restaurants
1. Rewrite `for-restaurants.html` using `Daydine For Restaurants.html` as visual target
2. Rewrite all copy against real pricing (£49 / £39) and real report contents
3. The preview/Companies House form is a lead-capture mock — wire to whatever lead capture you already have, or log to a form service
4. Delete `pricing.html` and `reports.html`
5. Add `vercel.json` rewrites so `/pricing` → `/for-restaurants#pricing` and `/reports` → `/for-restaurants#preview`

### Phase 5 — Rest of site
1. Restyle `methodology.html` in new tokens (content unchanged)
2. Restyle chrome of `search.html` (map + result list unchanged)
3. Restyle `sample.html`
4. Restyle `404.html`
5. Verify all cross-page links

### Phase 6 — Cutover
1. Full site QA on Vercel preview
2. Merge `redesign/editorial-v2` → `main`
3. Deploy
4. Monitor; have rollback ready

---

## 8. Fidelity guidance

**Match exactly:** typography (all weights/sizes/letter-spacing), colour palette, italic-accent pattern, ranked numeral treatment, the independence guarantee black bleed, button styling, section spacing.

**Allowed to adapt:** copy (must adapt to real data), exact pixel widths of instrument cards, specific form field labels (use whatever your real lead capture needs), the roadmap quarter dates.

**Do not introduce:** rounded corners > 3px, drop shadows (none in this system), gradient backgrounds, emoji, icon fonts, sans-serif for headlines, any font other than Newsreader / Inter / JetBrains Mono.

---

## 9. Files in this bundle

| File | Role |
|---|---|
| `Daydine Home.html` | Home page — visual target |
| `Daydine.html` | Rankings page — visual target (use variant "01 · Warm" only) |
| `Daydine For Restaurants.html` | Operator page — visual target |
| `home.css` | Home-page layout styles |
| `home-modules.css` | Shared modules (hero, cards, btn) — **contains the `.btn` rules** |
| `operator.css` | Operator-page layout styles |
| `styles.css` | Ranking page base styles |
| `variants.css` | 3 variant palettes — only use variant "paper"/"warm" |
| `app.jsx`, `data.js`, `drawers.jsx`, `shared.jsx`, `variant-*.jsx` | **Reference only.** Do not port as React. These files demonstrate structure and component boundaries; rebuild as plain HTML |

---

## 10. Not covered / open questions

1. **Restaurant detail page.** The mockup's drawer is a stand-in. You'll likely want a proper `/rankings/[market]/[slug].html` page per venue. Design it in the same system — big italic name, mono metadata, RCS breakdown with the three V4 components, band pill, convergence indicator, nearby/peer list.
2. **"Journal" / updates feed on home.** Content source TBD. Could be pulled from a `/updates.json` or hand-authored HTML.
3. **Newsletter.** Mockup has a signup block. Wire to your existing provider or remove.
4. **Operator preview form.** The Companies House + email form is a mock. Decide where this posts.
5. **Critic / editorial voice.** The mockup leans editorial. DayDine's real voice is more data-forward. Adjust copy accordingly — keep the typographic register, soften the "critic" implications.

---

Questions? Compare the live mockup at the sibling Claude project alongside this README and the real JSON files in `assets/rankings/`.
