// Daydine — main app shell with variant switcher + tweaks

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "variant": "dark",
  "showTicker": true,
  "showTweaksOnLoad": false
}/*EDITMODE-END*/;

function DaydineApp() {
  const groups = window.DAYDINE_DATA;

  // Persisted variant (allows switching via VariantTabs + Tweaks panel)
  const [variant, setVariant] = useState(() => {
    return localStorage.getItem("daydine.variant") || TWEAK_DEFAULTS.variant;
  });
  useEffect(() => { localStorage.setItem("daydine.variant", variant); }, [variant]);

  const [filterState, setFilterState] = useState({
    cuisine: "All", city: "All", price: "All", sort: "rank", q: ""
  });

  const [detail, setDetail] = useState(null); // { row, group }
  const [showMethod, setShowMethod] = useState(false);
  const [share, setShare] = useState(null); // { row, group }
  const [toast, setToast] = useState("");
  const [page, setPage] = useState("index");

  // Tweaks panel wiring
  const [tweaksOpen, setTweaksOpen] = useState(false);
  useEffect(() => {
    const onMsg = (e) => {
      if (!e.data) return;
      if (e.data.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const openDetail = useCallback((row, group) => setDetail({ row, group }), []);
  const closeDetail = useCallback(() => setDetail(null), []);
  const openShare = useCallback((row, group) => setShare({ row, group }), []);
  const closeShare = useCallback(() => setShare(null), []);
  const doCopy = useCallback((text) => {
    try {
      navigator.clipboard.writeText(text);
      setToast("COPIED TO CLIPBOARD");
    } catch {
      setToast("COPY FAILED");
    }
    setShare(null);
  }, []);

  // Keyboard shortcut: Esc closes everything
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { setDetail(null); setShare(null); setShowMethod(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const commonProps = {
    groups, filterState, setFilterState,
    onOpenDetail: openDetail,
    onOpenMethod: () => setShowMethod(true),
    onShare: openShare,
    currentPage: page, setPage
  };

  const variantClass = variant === "dark" ? "v-dark" : variant === "paper" ? "v-paper" : "v-neo";

  return (
    <>
      <VariantTabs variant={variant} setVariant={setVariant} />

      {variant === "dark" && <DarkTerminal {...commonProps} />}
      {variant === "paper" && <PaperTerminal {...commonProps} />}
      {variant === "neo" && <NeoTerminal {...commonProps} />}

      {detail && <DetailDrawer row={detail.row} group={detail.group} onClose={closeDetail} variantClass={variantClass} />}
      {showMethod && <MethodologyDrawer onClose={() => setShowMethod(false)} variantClass={variantClass} />}
      {share && <ShareSheet row={share.row} group={share.group} onClose={closeShare} onCopy={doCopy} variantClass={variantClass} />}

      <Toast msg={toast} onDone={() => setToast("")} />

      {tweaksOpen && <TweaksPanel
        variant={variant} setVariant={setVariant}
        filterState={filterState} setFilterState={setFilterState}
        onClose={() => setTweaksOpen(false)}
      />}
    </>
  );
}

function VariantTabs({ variant, setVariant }) {
  return (
    <div className="variant-tabs" data-screen-label="Variant Switcher">
      <div className="xnav">
        <a href="Daydine Home.html">← Home</a>
        <span className="xnav-on">The Lists</span>
        <a href="Daydine For Restaurants.html">For restaurants →</a>
        <span className="xnav-sep">·</span>
        <a className="xnav-claim" href="Daydine For Restaurants.html#preview">
          <em>Is this your restaurant?</em> See your position report
          <span className="xnav-arrow">↗</span>
        </a>
      </div>
      <button className={"variant-tab" + (variant === "dark" ? " on" : "")} onClick={() => setVariant("dark")}>
        01 · Warm
        <span className="tag">Cream paper · paprika accent · consumer friendly</span>
      </button>
      <button className={"variant-tab" + (variant === "paper" ? " on" : "")} onClick={() => setVariant("paper")}>
        02 · Editorial
        <span className="tag">Magazine kicker · big serif names · burnt sienna</span>
      </button>
      <button className={"variant-tab" + (variant === "neo" ? " on" : "")} onClick={() => setVariant("neo")}>
        03 · Dusk
        <span className="tag">Warm dark mode · candlelit amber · dinner-time</span>
      </button>
    </div>
  );
}

function TweaksPanel({ variant, setVariant, filterState, setFilterState, onClose }) {
  const set = (patch) => {
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
  };
  return (
    <div className="tweaks">
      <button className="tweak-close" onClick={onClose}>×</button>
      <h4>Tweaks</h4>
      <div className="tweak-row">
        <label>Variant</label>
        <div className="options">
          {["dark","paper","neo"].map(v => (
            <button key={v} className={v === variant ? "on" : ""} onClick={() => { setVariant(v); set({ variant: v }); }}>
              {v}
            </button>
          ))}
        </div>
      </div>
      <div className="tweak-row">
        <label>Sort</label>
        <div className="options">
          {["rank","score","delta","rankchg"].map(s => (
            <button key={s} className={s === filterState.sort ? "on" : ""} onClick={() => setFilterState({ ...filterState, sort: s })}>
              {s}
            </button>
          ))}
        </div>
      </div>
      <div className="tweak-row">
        <label>Price</label>
        <div className="options">
          {["All","$","$$","$$$","$$$$"].map(p => (
            <button key={p} className={p === filterState.price ? "on" : ""} onClick={() => setFilterState({ ...filterState, price: p })}>
              {p === "All" ? "·" : p}
            </button>
          ))}
        </div>
      </div>
      <div style={{fontSize:10, color:"#4a4a5a", marginTop:12, lineHeight:1.5}}>
        Click <b style={{color:"#c4ff00"}}>▲▼</b> beside any rank to see trend.<br/>
        Press <b style={{color:"#c4ff00"}}>Esc</b> to close panels.
      </div>
    </div>
  );
}

// Mount
ReactDOM.createRoot(document.getElementById("root")).render(<DaydineApp />);
