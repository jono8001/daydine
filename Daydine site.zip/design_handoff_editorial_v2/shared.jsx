// Daydine — shared UI primitives and utilities used across variants
const { useState, useMemo, useRef, useEffect, useCallback } = React;

// ---------- util ----------
function fmtScore(n) {
  return n.toFixed(2);
}
function fmtDelta(n) {
  const sign = n > 0 ? "+" : "";
  return sign + n.toFixed(2);
}
function fmtRankChange(n) {
  if (n === 0) return "—";
  return (n > 0 ? "▲" : "▼") + Math.abs(n);
}
function classNames(...xs) { return xs.filter(Boolean).join(" "); }

// ---------- Sparkline (pure SVG, no lib) ----------
function Sparkline({ score, prev, width = 56, height = 18, up, down, dim }) {
  // synthetic 8-point series ending at `score`, noising between prev and score
  const points = useMemo(() => {
    const pts = [];
    const n = 8;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      const base = prev + (score - prev) * t;
      // deterministic wiggle based on score
      const seed = Math.sin(score * 13.37 + i * 2.1) * 0.6;
      pts.push(base + seed);
    }
    return pts;
  }, [score, prev]);
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = Math.max(0.01, max - min);
  const stroke = score >= prev ? up : down;
  const path = points.map((p, i) => {
    const x = (i / (points.length - 1)) * width;
    const y = height - ((p - min) / range) * height;
    return (i === 0 ? "M" : "L") + x.toFixed(1) + "," + y.toFixed(1);
  }).join(" ");
  return (
    <svg width={width} height={height} style={{ display: "block" }}>
      <path d={path} fill="none" stroke={stroke} strokeWidth="1" />
    </svg>
  );
}

// ---------- Toast ----------
function Toast({ msg, onDone }) {
  useEffect(() => {
    if (!msg) return;
    const t = setTimeout(onDone, 1800);
    return () => clearTimeout(t);
  }, [msg, onDone]);
  if (!msg) return null;
  return (
    <div style={{
      position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)",
      background: "var(--fg)", color: "var(--bg)", padding: "8px 14px",
      fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.08em",
      textTransform: "uppercase", zIndex: 1000, border: "1px solid var(--fg)"
    }}>{msg}</div>
  );
}

// ---------- Filter bar (shared) ----------
function FilterBar({ state, set, groups, variant }) {
  const allCuisines = useMemo(() => {
    const s = new Set();
    groups.forEach(g => g.rows.forEach(r => s.add(r.cuisine)));
    return ["All", ...Array.from(s).sort()];
  }, [groups]);
  const allCities = useMemo(() => {
    const s = new Set();
    groups.forEach(g => g.rows.forEach(r => s.add(r.city)));
    return ["All", ...Array.from(s).sort()];
  }, [groups]);
  const prices = ["All","$","$$","$$$","$$$$"];
  const sorts = [
    { id: "rank", label: "Rank" },
    { id: "score", label: "Score" },
    { id: "delta", label: "Δ Score" },
    { id: "rankchg", label: "Δ Rank" },
    { id: "price", label: "Price" },
    { id: "newest", label: "Newest" }
  ];

  return (
    <div className={"filterbar filterbar-" + variant}>
      <Field label="CUISINE">
        <Select value={state.cuisine} onChange={v => set({ ...state, cuisine: v })} opts={allCuisines} />
      </Field>
      <Field label="CITY">
        <Select value={state.city} onChange={v => set({ ...state, city: v })} opts={allCities} />
      </Field>
      <Field label="PRICE">
        <SegPrice value={state.price} onChange={v => set({ ...state, price: v })} opts={prices} />
      </Field>
      <Field label="SORT">
        <Select value={state.sort} onChange={v => set({ ...state, sort: v })} opts={sorts.map(s => s.id)} labels={Object.fromEntries(sorts.map(s => [s.id, s.label]))} />
      </Field>
      <div className="filter-spacer" />
      <Field label="SEARCH">
        <input
          className="search"
          placeholder="name, chef, dish…"
          value={state.q}
          onChange={e => set({ ...state, q: e.target.value })}
        />
      </Field>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
    </label>
  );
}
function Select({ value, onChange, opts, labels }) {
  return (
    <select className="select" value={value} onChange={e => onChange(e.target.value)}>
      {opts.map(o => <option key={o} value={o}>{labels ? labels[o] : o}</option>)}
    </select>
  );
}
function SegPrice({ value, onChange, opts }) {
  return (
    <div className="seg">
      {opts.map(o => (
        <button key={o}
          className={"seg-btn" + (o === value ? " seg-btn-on" : "")}
          onClick={() => onChange(o)}>{o === "All" ? "·" : o}</button>
      ))}
    </div>
  );
}

// ---------- Apply filters + sort to a group ----------
function filterAndSort(rows, state) {
  let out = rows;
  if (state.cuisine !== "All") out = out.filter(r => r.cuisine === state.cuisine);
  if (state.city !== "All") out = out.filter(r => r.city === state.city);
  if (state.price !== "All") out = out.filter(r => r.price === state.price);
  if (state.q && state.q.trim()) {
    const q = state.q.trim().toLowerCase();
    out = out.filter(r =>
      r.name.toLowerCase().includes(q) ||
      r.chef.toLowerCase().includes(q) ||
      r.notable.toLowerCase().includes(q) ||
      r.neighborhood.toLowerCase().includes(q)
    );
  }
  const sorters = {
    rank: (a, b) => a.rank - b.rank,
    score: (a, b) => b.score - a.score,
    delta: (a, b) => b.delta - a.delta,
    rankchg: (a, b) => b.rankChange - a.rankChange,
    price: (a, b) => a.price.length - b.price.length,
    newest: (a, b) => b.openedYear - a.openedYear
  };
  out = [...out].sort(sorters[state.sort] || sorters.rank);
  return out;
}

Object.assign(window, {
  fmtScore, fmtDelta, fmtRankChange, classNames,
  Sparkline, Toast, FilterBar, filterAndSort
});
