// Daydine — Variant B: Editorial (magazine-feel broadsheet)

function PaperTerminal({ groups, filterState, setFilterState, onOpenDetail, onOpenMethod, onShare, currentPage, setPage }) {
  const filteredGroups = groups.map(g => ({ ...g, rows: filterAndSort(g.rows, filterState) }))
                                .filter(g => g.rows.length > 0);
  const META = window.DAYDINE_META;

  return (
    <div className="v-paper page" data-screen-label="Editorial">
      <div className="topbar">
        <div className="brand">Day<em>dine</em></div>
        <div className="topbar-meta">
          <span>VOL XII · NO. 02</span>
          <span>SPRING <b>2026</b></span>
          <span>EDITION <b>{META.updated}</b></span>
        </div>
      </div>

      <div className="sub-top">
        <a className={currentPage === "index" ? "on" : ""} onClick={() => setPage("index")}>The Lists</a>
        <a onClick={onOpenMethod}>Methodology</a>
        <a>Critics</a>
        <a>Journal</a>
        <a>Archive</a>
        <span style={{marginLeft:"auto", fontSize:12, color:"var(--fg-dim)"}}>
          {META.totalTracked.toLocaleString()} restaurants tracked · {Object.keys(groups).length} cities in print
        </span>
      </div>

      <div className="kicker">
        Twenty restaurants per city, ranked with care. The cities are British; the work is the same every season —
        <b> we eat, we argue, we rewrite the list.</b> What you see below is the version we are willing to defend this week.
      </div>

      <FilterBar state={filterState} set={setFilterState} groups={groups} variant="paper" />

      <div className="main">
        {filteredGroups.map((g, gi) => (
          <section key={g.id} className="group">
            <div className="group-head">
              <div>
                <div className="group-kind">{g.kind === "city" ? "The " + g.label + " Twenty" : "Global · " + g.label}</div>
                <div className="group-label">{g.label}</div>
              </div>
              <div className="group-count">{g.rows.length} restaurants · ranked 1–20</div>
            </div>
            <table className="table">
              <thead className="thead">
                <tr>
                  <th style={{width:52, paddingLeft:24}}>#</th>
                  <th>Restaurant</th>
                  <th>Cuisine · Neighborhood</th>
                  <th style={{textAlign:"right"}}>Score</th>
                  <th style={{textAlign:"right"}}>Δ Score</th>
                  <th style={{textAlign:"right"}}>Δ Rank</th>
                  <th>Trend</th>
                  <th>Tier</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {g.rows.map(r => <PaperRow key={g.id + "-" + r.rank + "-" + r.name} r={r} onOpen={onOpenDetail} onShare={onShare} group={g} />)}
              </tbody>
            </table>
          </section>
        ))}
        {filteredGroups.length === 0 && (
          <div style={{padding:"80px 28px", color:"var(--fg-dim)", fontFamily:"var(--serif)", fontStyle:"italic", fontSize:18}}>
            Nothing here. Try loosening a filter.
          </div>
        )}
      </div>

      <div className="paper-footer">
        <span>© 2026 <b>Daydine Media</b></span>
        <span>Methodology <b>v4.2</b></span>
        <span style={{marginLeft:"auto"}}>Reviews, reservations, repeats. In that order.</span>
      </div>
    </div>
  );
}

function PaperRow({ r, onOpen, onShare, group }) {
  const up = r.delta > 0, down = r.delta < 0;
  const deltaClass = up ? "delta-up" : down ? "delta-down" : "delta-flat";
  const rankUp = r.rankChange > 0, rankDown = r.rankChange < 0;
  return (
    <tr className={"tr" + (r.rank <= 3 ? " top3" : "")}>
      <td className="td td-rank num">{String(r.rank).padStart(2, "0")}</td>
      <td className="td td-name">
        <a onClick={() => onOpen(r, group)}>{r.name}</a>
        <div className="td-addr">{r.address}</div>
      </td>
      <td className="td td-meta">{r.cuisine} · <em>{r.neighborhood}</em></td>
      <td className="td td-score num">{fmtScore(r.score)}</td>
      <td className={"td td-delta num " + deltaClass}>{fmtDelta(r.delta)}</td>
      <td className={"td td-delta num " + (rankUp ? "delta-up" : rankDown ? "delta-down" : "delta-flat")}>
        {fmtRankChange(r.rankChange)}
      </td>
      <td className="td td-spark">
        <Sparkline score={r.score} prev={r.prevScore}
          up={"var(--up)"} down={"var(--down)"} dim={"var(--fg-faint)"} />
      </td>
      <td className="td td-price num">{r.price}</td>
      <td className="td td-share">
        <button className="sharebtn" onClick={(e) => { e.stopPropagation(); onShare(r, group); }}>Share</button>
      </td>
    </tr>
  );
}

Object.assign(window, { PaperTerminal });
