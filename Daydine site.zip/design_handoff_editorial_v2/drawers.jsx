// Daydine — Detail drawer + Methodology drawer + Share sheet

function DetailDrawer({ row, group, onClose, variantClass }) {
  if (!row) return null;
  const rankHistory = useMemo(() => {
    const rng = Math.sin(row.score * 31.7);
    const pts = [];
    for (let i = 0; i < 12; i++) {
      const seed = Math.sin(row.score * 13 + i * 2.3);
      const r = Math.max(1, Math.min(20, Math.round(row.rank + seed * 5 - i * 0.3)));
      pts.push(r);
    }
    pts.push(row.rank);
    return pts;
  }, [row]);
  const maxRank = 20;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className={"modal-panel " + variantClass} onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>ESC ×</button>
        <div className="detail-hero">
          <div className="detail-rank">
            {group.label.toUpperCase()} · RANK #{row.rank} OF 20
          </div>
          <h2 className="detail-name">{row.name}</h2>
          <div className="detail-meta">
            {row.cuisine}<span className="sep">/</span>
            {row.neighborhood}, {row.city}<span className="sep">/</span>
            {row.price}<span className="sep">/</span>
            est. {row.openedYear}
          </div>
        </div>

        <div className="detail-grid">
          <div className="detail-stat">
            <div className="stat-label">Daydine Score</div>
            <div className="stat-value num">{fmtScore(row.score)}</div>
          </div>
          <div className="detail-stat">
            <div className="stat-label">Δ vs Q1</div>
            <div className={"stat-value num " + (row.delta >= 0 ? "delta-up" : "delta-down")}>
              {fmtDelta(row.delta)}
            </div>
          </div>
          <div className="detail-stat">
            <div className="stat-label">Rank Change</div>
            <div className={"stat-value num " + (row.rankChange > 0 ? "delta-up" : row.rankChange < 0 ? "delta-down" : "delta-flat")}>
              {fmtRankChange(row.rankChange)}
            </div>
          </div>
          <div className="detail-stat">
            <div className="stat-label">Review Count</div>
            <div className="stat-value num">{row.reviews.toLocaleString()}</div>
          </div>
        </div>

        <div className="detail-section">
          <h4>RANK HISTORY · LAST 13 PERIODS</h4>
          <div className="rank-history">
            {rankHistory.map((r, i) => {
              const h = ((maxRank - r + 1) / maxRank) * 100;
              const isLast = i === rankHistory.length - 1;
              return (
                <div key={i} className="rank-bar" style={{
                  height: h + "%",
                  background: isLast ? "var(--accent)" : "var(--fg-faint)"
                }}>
                  {isLast && <div className="rank-bar-label">NOW</div>}
                </div>
              );
            })}
          </div>
        </div>

        <div className="detail-section">
          <h4>NOTABLE</h4>
          <p>Chef <b>{row.chef}</b>. Known for <i>{row.notable}</i>. {row.seats} seats. Average wait: <b>{row.waitDays} days</b>.</p>
        </div>

        <div className="detail-section">
          <h4>SCORE COMPONENTS</h4>
          <div style={{fontSize:12}}>
            <ComponentBar label="Critic Reviews" value={Math.min(100, row.score + Math.sin(row.score) * 3)} />
            <ComponentBar label="Reservation Velocity" value={Math.min(100, row.score - 2 + Math.sin(row.score * 2.1) * 4)} />
            <ComponentBar label="Repeat-Visit Rate" value={Math.min(100, row.score + Math.sin(row.score * 3.2) * 5)} />
            <ComponentBar label="Peer Rank" value={Math.min(100, row.score - 1 + Math.sin(row.score * 4.3) * 3)} />
          </div>
        </div>

        <div className="detail-section" style={{borderBottom:0}}>
          <h4>NEXT IN LIST</h4>
          <div style={{display:"flex", gap:8, fontSize:12, color:"var(--fg-dim)"}}>
            {group.rows.filter(x => Math.abs(x.rank - row.rank) <= 2 && x.name !== row.name).map(x => (
              <span key={x.name} style={{padding:"4px 8px", border:"1px solid var(--rule)"}}>
                #{x.rank} {x.name} <span style={{color:"var(--fg-faint)"}}>{fmtScore(x.score)}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ComponentBar({ label, value }) {
  return (
    <div style={{marginBottom:10}}>
      <div style={{display:"flex", justifyContent:"space-between", marginBottom:4, fontSize:10, letterSpacing:"0.1em"}}>
        <span style={{color:"var(--fg-dim)", textTransform:"uppercase"}}>{label}</span>
        <span className="num">{value.toFixed(1)}</span>
      </div>
      <div style={{height:2, background:"var(--rule)"}}>
        <div style={{height:"100%", background:"var(--fg)", width: value + "%"}} />
      </div>
    </div>
  );
}

function MethodologyDrawer({ onClose, variantClass }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className={"modal-panel " + variantClass} onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>ESC ×</button>
        <div className="method-body">
          <div className="detail-rank">HOW DAYDINE RANKS</div>
          <h2 className="detail-name" style={{marginBottom:24}}>The Methodology</h2>

          <h3>01 · THE INDEX</h3>
          <p>
            Every tracked restaurant receives a Daydine Score between 0.00 and 100.00, updated quarterly.
            Scores are computed from four weighted components and normalized against cohort — a dinner spot
            is only compared to dinner spots of the same tier.
          </p>

          <h3>02 · COMPONENT WEIGHTS</h3>
          <div>
            <div className="weight-row"><span>CRITIC REVIEWS — aggregated from 140+ publications</span><b>35%</b></div>
            <div className="weight-row"><span>RESERVATION VELOCITY — demand signals across booking platforms</span><b>25%</b></div>
            <div className="weight-row"><span>REPEAT-VISIT RATE — loyalty of verified diners</span><b>25%</b></div>
            <div className="weight-row"><span>PEER RANK — chef & industry surveys</span><b>15%</b></div>
          </div>

          <h3>03 · GROUPS OF 20</h3>
          <p>
            We publish the list in groups of 20 because it is the natural unit of a dining city —
            enough to cover a neighborhood's best work, small enough to read in one sitting. Cities get
            their own group; cuisines get a global cross-cut.
          </p>

          <h3>04 · WHAT WE DO NOT DO</h3>
          <ul>
            <li>We do not take payment for placement.</li>
            <li>We do not accept complimentary meals from subjects.</li>
            <li>We do not disclose anonymous critics.</li>
          </ul>

          <h3>05 · CORRECTIONS</h3>
          <p>
            Errors are fixed within 48 hours and logged in the public Changelog. The current
            methodology version is <b>v4.2</b>, adopted Q1 2026.
          </p>
        </div>
      </div>
    </div>
  );
}

function ShareSheet({ row, group, onClose, onCopy, variantClass }) {
  const url = `https://daydine.co/${group.id}/${row.rank}-${row.name.toLowerCase().replace(/\s+/g,"-")}`;
  return (
    <div className="share-sheet" onClick={onClose}>
      <div className={"share-card " + variantClass} onClick={e => e.stopPropagation()}>
        <h3>SHARE RANKING</h3>
        <div className="share-preview">
          <div className="p-rank">{group.label} · #{row.rank} of 20</div>
          <div className="p-name">{row.name}</div>
          <div className="p-meta">{row.cuisine} · {row.neighborhood}</div>
          <div className="p-score num">
            {fmtScore(row.score)}{" "}
            <span style={{fontSize:14, color: row.delta >= 0 ? "var(--up)" : "var(--down)"}}>
              {fmtDelta(row.delta)}
            </span>
          </div>
        </div>
        <div style={{fontSize:10, color:"var(--fg-dim)", letterSpacing:"0.1em", marginBottom:8, wordBreak:"break-all"}}>
          {url}
        </div>
        <div className="share-actions">
          <button className="share-btn" onClick={() => onCopy(url)}>Copy link</button>
          <button className="share-btn" onClick={() => onCopy(`#${row.rank} in ${group.label}: ${row.name} — ${fmtScore(row.score)} on Daydine.`)}>Copy card</button>
          <button className="share-btn" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DetailDrawer, MethodologyDrawer, ShareSheet });
