// Daydine — Variant C: Dusk (warm dining room, after-hours)

function NeoTerminal({ groups, filterState, setFilterState, onOpenDetail, onOpenMethod, onShare, currentPage, setPage }) {
  const filteredGroups = groups.map(g => ({ ...g, rows: filterAndSort(g.rows, filterState) }))
                                .filter(g => g.rows.length > 0);
  const META = window.DAYDINE_META;

  return (
    <div className="v-neo page" data-screen-label="Dusk">
      <div className="topbar">
        <div className="brand">Daydine</div>
        <nav className="navlinks">
          <a className={currentPage === "index" ? "on" : ""} onClick={() => setPage("index")}>The Lists</a>
          <a onClick={onOpenMethod}>How we rank</a>
          <a>Book a table</a>
        </nav>
        <div className="topbar-meta">
          <span>Spring <b>2026</b></span>
          <span><b>{META.totalTracked.toLocaleString()}</b> tracked</span>
        </div>
      </div>

      <div className="tagline">
        Where shall we eat tonight? <b>Twenty answers per city</b>, ranked — the places worth the trip across town,
        picked by people who've queued for the last table on a wet Tuesday.
      </div>

      <FilterBar state={filterState} set={setFilterState} groups={groups} variant="neo" />

      <div className="main">
        {filteredGroups.map((g, gi) => (
          <section key={g.id} className="group">
            <div className="group-head">
              <div>
                <div className="group-kind">
                  {g.kind === "city" ? <>the twenty · <em>{g.label.toLowerCase()}</em></> : <>global cross-cut · <em>{g.label.split("·")[0].trim().toLowerCase()}</em></>}
                </div>
                <div className="group-label">{g.label}<sup>{g.rows.length}</sup></div>
              </div>
              <div className="group-count">ranked 1→20 · updated {META.updated}</div>
            </div>
            <table className="table">
              <thead className="thead">
                <tr>
                  <th style={{width:60}}>rank</th>
                  <th>restaurant</th>
                  <th>cuisine · area</th>
                  <th style={{textAlign:"right"}}>score</th>
                  <th style={{textAlign:"right"}}>Δ score</th>
                  <th style={{textAlign:"right"}}>Δ rank</th>
                  <th>trend</th>
                  <th>price</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {g.rows.map(r => <DuskRow key={g.id + "-" + r.rank + "-" + r.name} r={r} onOpen={onOpenDetail} onShare={onShare} group={g} />)}
              </tbody>
            </table>
          </section>
        ))}
        {filteredGroups.length === 0 && (
          <div style={{padding:"80px 28px", color:"var(--fg-dim)", fontFamily:"var(--serif)", fontStyle:"italic", fontSize:18}}>
            Nothing here tonight. Try a different filter.
          </div>
        )}
      </div>

      <div className="neo-footer">
        <span><b>Daydine</b> · an honest list of where to eat</span>
        <span>Spring <b>2026</b></span>
        <span>Methodology <b>v4.2</b></span>
        <span style={{marginLeft:"auto"}}>© 2026</span>
      </div>
    </div>
  );
}

function DuskRow({ r, onOpen, onShare, group }) {
  const up = r.delta > 0, down = r.delta < 0;
  const deltaClass = up ? "delta-up" : down ? "delta-down" : "delta-flat";
  const rankUp = r.rankChange > 0, rankDown = r.rankChange < 0;
  return (
    <tr className={"tr" + (r.rank <= 3 ? " top3" : "")}>
      <td className="td td-rank num"><span className="hash">#</span>{r.rank}</td>
      <td className="td td-name">
        <a onClick={() => onOpen(r, group)}>{r.name}</a>
        <div className="td-addr">{r.address}</div>
      </td>
      <td className="td td-meta">{r.cuisine} <span className="dot">·</span> <em>{r.neighborhood}</em></td>
      <td className="td td-score num">{fmtScore(r.score)}</td>
      <td className={"td td-delta num " + deltaClass}>{fmtDelta(r.delta)}</td>
      <td className={"td td-delta num " + (rankUp ? "delta-up" : rankDown ? "delta-down" : "delta-flat")}>
        {fmtRankChange(r.rankChange)}
      </td>
      <td className="td td-spark">
        <Sparkline score={r.score} prev={r.prevScore}
          up={"var(--up)"} down={"var(--down)"} dim={"var(--fg-faint)"} />
      </td>
      <td className="td td-price num">{r.price}</td>
      <td className="td td-share">
        <button className="sharebtn" onClick={(e) => { e.stopPropagation(); onShare(r, group); }}>Share</button>
      </td>
    </tr>
  );
}

Object.assign(window, { NeoTerminal });
