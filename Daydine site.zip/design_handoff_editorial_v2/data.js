// Daydine — UK-focused data
// Groups of 20, ranked 1-20 within each group

const CUISINES = ["Modern British","Italian","Japanese","French","Thai","Korean","Indian","Chinese","Spanish","Levantine","Nordic","Turkish","Portuguese","Vietnamese","Pan-Asian","Ethiopian","Steakhouse","Seafood","Bistro","Natural Wine"];

// UK neighbourhoods per city — these become the 20 slots per city list
const NEIGHBOURHOODS = {
  "London": ["Soho","Shoreditch","Mayfair","Fitzrovia","Marylebone","Notting Hill","Covent Garden","Bermondsey","Hackney","Dalston","Peckham","King's Cross","Clerkenwell","Chelsea","Kensington","Brixton","Islington","Borough","Bethnal Green","Stoke Newington"],
  "Manchester": ["Ancoats","Northern Quarter","Spinningfields","Deansgate","Castlefield","Chorlton","Didsbury","Prestwich","Ardwick","Withington","Levenshulme","Salford","Altrincham","Hulme","Rusholme","Stretford","Heaton Moor","Media City","Cheadle","Sale"],
  "Edinburgh": ["New Town","Old Town","Leith","Stockbridge","Bruntsfield","Morningside","Canonmills","Haymarket","Tollcross","Grassmarket","Newington","Marchmont","Dean Village","Broughton","Fountainbridge","Portobello","West End","Southside","Abbeyhill","Corstorphine"],
  "Bristol": ["Clifton","Stokes Croft","Wapping Wharf","Montpelier","Redland","Bedminster","Southville","St. Werburgh's","Cotham","Easton","Totterdown","Bishopston","Gloucester Rd","Old City","Harbourside","Temple Quarter","St. Paul's","Kingsdown","Cliftonwood","Redcliffe"],
  "Leeds": ["Chapel Allerton","Call Lane","Headingley","Meanwood","Roundhay","Kirkgate","Holbeck","Horsforth","Oakwood","Chapeltown","Harehills","Hyde Park","Farsley","Moortown","Seacroft","Beeston","Burley","Briggate","Thornton's Arcade","Leeds Dock"],
  "Brighton": ["The Lanes","North Laine","Hove","Kemptown","Seven Dials","Preston Park","Fiveways","Portslade","Hanover","Brunswick","Regency Sq","Queen's Park","Poets Corner","Round Hill","Montpelier","Cliftonville","Withdean","Patcham","Ovingdean","Rottingdean"]
};

// UK-appropriate restaurant names (fictional but plausible) — mostly short, textural, a little weird
const NAME_POOLS = {
  "Modern British": ["The Clove Club","Smoking Goat","Brat","Rochelle","St. JOHN","Lyle's","Trivet","Kiln","P. Franco","Cuckoo","The Quality Chop","Bright","Manteca","Anglo","The Ninth","Compound","Ikoyi","The Sea, The Sea","Hide","Rochelle Canteen"],
  "Italian": ["Padella","Bocca di Lupo","Trullo","Bancone","Flor","Cafe Murano","Polpo","Lina Stores","Luca","Passione","Ravioli Bros","Osteria Tufo","Primi","Campo","La Barra","Riposo","Quo Vadis","Brutto","Zelman","Sartoria"],
  "Japanese": ["Koya","Sosharu","Endo","Sushi Tetsu","Zuma","Chisou","Tonkotsu","Kiraku","Ichibuns","Roketsu","Yashin","Taka","Machiya","Oisoi","Sushi Atelier","Humble Grape Sushi","Murakami","Nobu Mayfair","Sanshiro","Dinings"],
  "French": ["Chez Bruce","Clos Maggiore","Noble Rot","Maison François","Bouchon Racine","Petit Pois","Colbert","Brasserie Zédel","Cafe Cecilia","Camille","L'Entrecôte","Brasserie Blanc","La Trompette","Les 2 Garçons","Mon Plaisir","Terroirs","Cafe Deco","Otto's","Bibendum","Le Gavroche"],
  "Thai": ["Som Saa","Farang","Singburi","Kiln","Speedboat Bar","Plaza Khao Gaeng","Rosa's","Paatara","Smokin' Kow","Mae Jum","Supawan","101 Thai","Sanam","Baan Pad Thai","Thai Square","Giggling Squid","AngloThai","Busaba","Patara","Addie's"],
  "Korean": ["Kol","Sollip","Gaya","Jinjuu","Koba","Seoul Bird","Kimchee","Yori","Oisoi","Bibimbap","Sanchon","On The Bab","Cah-Chi","Cub","Bulgogi","Naru","Cafe Kimichi","Asadal","Koppe","Banchan"],
  "Indian": ["Dishoom","Gymkhana","Trishna","Benares","Darjeeling Express","Chourangi","BiBi","Indian Accent","Kutir","Quilon","Pahli Hill","Opheem","Mount Street Restaurant","Tayyabs","Dishoom Battersea","Brigadiers","Chutney Mary","Amaya","Cinnamon Club","Kolamba"],
  "Chinese": ["Xu","Bao","A. Wong","Plum Valley","Hakkasan","Yauatcha","Baiwei","Four Seasons","Master Wei","Silk Road","Dumpling Shack","Din Tai Fung","Royal China","Hutong","Imperial Treasure","Tattu","Park Chinois","Sichuan House","Chi Kitchen","Duddell's"],
  "Spanish": ["Barrafina","Morito","Jose Pizarro","Sabor","Kiln Pintxos","Brindisa","Lurra","Sabor Roastery","Boqueria","Copita","Cigala","Moro","Eneko","Ibérica","El Pastor","Casa Madera","Tapas Brindisa","Jamon","Brawn","Tierra"],
  "Levantine": ["Palomar","Barbary","Berenjak","Honey & Co","Oklava","Jikoni","Ottolenghi","Tavolino","Palmyra","Xian","Saba","Som Saa","Kibele","Gazelle","Momo","Fez Mangal","Damas","Jerusalem","Zahir","Zahter"],
  "Nordic": ["Aquavit","Texture","Hedone","Ekstedt","Noble","Frog","Folkvang","Roots","Fjord","Skog","Nordic Bakery","Rök","Nordica","Stockholm","Björk","Hav","Gran","Sol","Lagom","Aske"],
  "Turkish": ["Oklava","Gazelle","Smoking Bowl","Yosma","Firat","Mangal","Gülhane","Han","Türk","Sahin","19 Numara","Firin","Cirrik","Kervan","Skewd","Best Mangal","Hala","Marka","Pillars","Black Axe Mangal"],
  "Portuguese": ["Bar Douro","Canteen","Taberna Do Mercado","Lisboeta","Café Tejo","Ponte","Rua Flor","Travessa","O Fado","Petisco","Porto","Algarve","Tágides","Trindade","Rota","Ferroviário","Boteco","Duas Portas","Alfama","Bairro"],
  "Vietnamese": ["BúnBúnBún","Pho","Mien Tay","Keu","Viet Grill","Saigon","Sông Quê","Cay Tre","Banh Mi 11","Pho Mile","Mama Lan","Lanzhou","Cafe East","Viet Hoa","Hanoi","Hue","Bánh Bao","Phở Tàu Bay","Mai'S","Huong-Viet"],
  "Pan-Asian": ["Kricket","Chotto","Ember Yard","Eat Tokyo","Hoppers","Kudu","Paradise","Sambal Shiok","Kuzu","Ugly Butterfly","Akub","Wan","Tim Ho Wan","Andu","Kintan","Kajjen","Kimchee","Yamabahçe","Nanban","Kym's"],
  "Ethiopian": ["Addis","Lalibela","Queen of Sheba","Merkato","Zeret","Adulis","Abyssinia","Tropical","Habesha","Keren","Blue Nile","Injera","Mesob","Awash","Zagwe","Makeda","Tigray","Amharic","Selam","Sheba"],
  "Steakhouse": ["Hawksmoor","Goodman","Blacklock","Smith & Wollensky","Flat Iron","Barbecoa","Zelman","Cut","Butcher","The Guinea","Gaucho","Beast","Bodean's","Macellaio","34","Sophie's","Boisdale","M Restaurants","Rowley's","The Jugged Hare"],
  "Seafood": ["Sweetings","J Sheekey","Scott's","Wright Brothers","Rex Whistler","Angler","Outlaw's","Pearl","Orrery","Prawn on the Lawn","Bentley's","Kerridge's Fish","Cornerstone","The Sea Shell","Fulham Shore","Angel","One-O-One","Seafresh","Seabird","Wheelers"],
  "Bistro": ["Bouchon Racine","Quality Wines","40 Maltby","Westerns Laundry","Primeur","Rochelle","Jolene","Planque","Sessions","Cafe Cecilia","Noble Rot","Toklas","Two Lights","Cafe Deco","Petersham","Bistrotheque","Little French","The Anchor","The Canton Arms","The Pig & Butcher"],
  "Natural Wine": ["P. Franco","Noble Rot","Top Cuvée","Bright","Leroy","Sager + Wilde","Hector's","Quality Wines","40 Maltby","Planque","Bar Crispin","Top Pick","Sourced Market","Kinky Fresh","Coq d'Argent","Flor","Brawn","Ducksoup","Primeur","The Remedy"]
};

// London street patterns — realistic, varied
const STREET_NAMES = ["Redchurch St","Dean St","Broadway Market","Exmouth Mkt","Frith St","Berwick St","Brushfield St","Kingsland Rd","Columbia Rd","Borough High St","Leather Lane","Charlotte St","Cleveland St","Lamb's Conduit St","Rye Lane","Bermondsey St","Hackney Rd","Mare St","Chatsworth Rd","Lower Marsh","Great Portland St","Warren St","Marchmont St","Mortimer St","Poland St","Old Compton St","Rupert St","Greek St","Wardour St","Chalk Farm Rd","Kensington Park Rd","Westbourne Grove","Pembridge Rd","All Saints Rd","Golborne Rd","Portobello Rd","Lordship Lane","Stoke Newington Church St","Church St","High St","Bethnal Green Rd","Hoxton Sq","Hoxton St","Shoreditch High St","Old St","Goswell Rd","St John St","Rosebery Ave","Upper St","Cross St","Essex Rd","Liverpool Rd","Holloway Rd","Newington Green","Stamford Hill","Kingsland High St"];

function mulberry32(a) {
  return function() {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
}

function makeAddress(rng, city, neighbourhood) {
  const num = 1 + Math.floor(rng() * 240);
  let street;
  if (city === "London") {
    street = STREET_NAMES[Math.floor(rng() * STREET_NAMES.length)];
  } else {
    // Generic UK street suffixes for other cities
    const bases = ["High St","Church St","Market St","King St","Queen St","North St","South St","Mill Rd","Station Rd","Union St","Park Rd","Albion St","Albert St","Victoria St","The Parade","West St","East St"];
    street = bases[Math.floor(rng() * bases.length)];
  }
  // Build a short UK-style postcode stub
  const postPrefixes = {
    "London": ["E1","E2","E8","E9","N1","N16","SE1","SE15","SW1","SW3","W1","W11","EC1","EC2","WC1","WC2","NW1","NW5"],
    "Manchester": ["M1","M2","M3","M4","M15","M20","M21"],
    "Edinburgh": ["EH1","EH2","EH3","EH6","EH8","EH10"],
    "Bristol": ["BS1","BS2","BS3","BS6","BS8"],
    "Leeds": ["LS1","LS2","LS6","LS7","LS8"],
    "Brighton": ["BN1","BN2","BN3"]
  };
  const pre = postPrefixes[city] || ["UK1"];
  const prefix = pre[Math.floor(rng() * pre.length)];
  const suffix = Math.floor(rng() * 9) + " " + String.fromCharCode(65 + Math.floor(rng()*26)) + String.fromCharCode(65 + Math.floor(rng()*26));
  return `${num} ${street}, ${city} ${prefix}${suffix}`;
}

function buildData() {
  const rng = mulberry32(20260420);
  const pick = (arr) => arr[Math.floor(rng() * arr.length)];
  const cities = Object.keys(NEIGHBOURHOODS);
  const groups = [];

  cities.forEach(city => {
    const used = new Set();
    const rows = [];
    for (let i = 0; i < 20; i++) {
      const cuisine = pick(CUISINES);
      let name;
      let attempts = 0;
      do {
        name = pick(NAME_POOLS[cuisine]);
        attempts++;
      } while (used.has(name) && attempts < 30);
      used.add(name);

      const neighbourhood = NEIGHBOURHOODS[city][i];
      const score = +(99.2 - i * (0.22 + rng() * 0.35) - rng() * 0.3).toFixed(2);
      const prevScore = +(score + (rng() * 2 - 1) * 0.9).toFixed(2);
      const delta = +(score - prevScore).toFixed(2);
      const priceLevels = ["£","££","£££","££££"];
      const price = priceLevels[Math.floor(rng() * 4)];
      const reviews = Math.floor(120 + rng() * 4800);
      const openedYear = 2008 + Math.floor(rng() * 18);
      const seats = 18 + Math.floor(rng() * 120);
      const waitDays = Math.floor(rng() * 90);
      const rankChange = Math.floor((rng() - 0.5) * 12);

      rows.push({
        rank: i + 1,
        name,
        cuisine,
        neighborhood: neighbourhood,
        city,
        address: makeAddress(rng, city, neighbourhood),
        price,
        score, prevScore, delta, rankChange,
        reviews, openedYear, seats, waitDays,
        chef: pickChef(rng),
        notable: pickDish(rng, cuisine)
      });
    }
    groups.push({
      id: city.toLowerCase().replace(/\s+/g,"-"),
      label: city,
      kind: "city",
      rows
    });
  });

  // Cross-cut: global-British groupings (still UK audience, but cuisine-first)
  ["Natural Wine","Indian","Modern British"].forEach(cu => {
    const rows = [];
    const used = new Set();
    for (let i = 0; i < 20; i++) {
      let name;
      let attempts = 0;
      do {
        name = pick(NAME_POOLS[cu]);
        attempts++;
      } while (used.has(name) && attempts < 30);
      if (used.has(name)) name = name + " " + (i+1);
      used.add(name);

      const city = pick(cities);
      const neighbourhood = pick(NEIGHBOURHOODS[city]);
      const score = +(98.6 - i * 0.3 - rng() * 0.4).toFixed(2);
      const prevScore = +(score + (rng() * 2 - 1) * 0.9).toFixed(2);
      const delta = +(score - prevScore).toFixed(2);
      rows.push({
        rank: i + 1,
        name,
        cuisine: cu,
        neighborhood: neighbourhood,
        city,
        address: makeAddress(rng, city, neighbourhood),
        price: ["£","££","£££","££££"][Math.floor(rng() * 4)],
        score, prevScore, delta,
        rankChange: Math.floor((rng() - 0.5) * 12),
        reviews: Math.floor(80 + rng() * 3200),
        openedYear: 2010 + Math.floor(rng() * 16),
        seats: 16 + Math.floor(rng() * 80),
        waitDays: Math.floor(rng() * 60),
        chef: pickChef(rng),
        notable: pickDish(rng, cu)
      });
    }
    groups.push({
      id: cu.toLowerCase().replace(/\s+/g,"-"),
      label: cu + " · Across the UK",
      kind: "cuisine",
      rows
    });
  });

  return groups;
}

function pickChef(rng) {
  const first = ["M.","J.","A.","K.","S.","T.","R.","L.","N.","E.","Y.","H.","P.","C.","O."];
  const last = ["Adjonyoh","Lindqvist","Patel","Morrison","Bianchi","Tanaka","Nakamura","Akinola","Kohli","Chen","Romano","Abadi","Singh","Begum","Ishikawa","O'Connor","Costa","Yuen","Halabi","Gill","Ferrer","Saad","Winters","Greco","Navarro","Gillespie","Hartnett","Sethi","Lubbock","Ottolenghi","Ramsay","Lee","Dempsey","Brown","MacAulay","Kelly"];
  return first[Math.floor(rng()*first.length)] + " " + last[Math.floor(rng()*last.length)];
}

function pickDish(rng, cuisine) {
  const dishes = {
    "Modern British":["roast quail, lovage","sea bream, sea herbs","mutton with anchovy","roast bone marrow","Eccles cake with Lancashire","smoked cod's roe","ox cheek & bone marrow","Welsh rarebit, XO","crab on toast","sloe gin jelly"],
    "Italian":["tagliolini al tartufo","cacio e pepe","vitello tonnato","risotto alla milanese","bollito misto","pici all'aglione","nduja panzerotti","focaccia & stracciatella","agnolotti del plin","pollo alla diavola"],
    "Japanese":["uni chawanmushi","A5 tataki","anago nigiri","kaiseki tasting","cold soba","udon in hot broth","tempura of courgette flower","yaki onigiri","miso aubergine","hand roll set"],
    "French":["duck à l'orange","bouillabaisse","tarte Tatin","steak au poivre","île flottante","coq au vin","lièvre à la royale","boudin noir","sole meunière","œuf mayonnaise"],
    "Thai":["khao soi","som tam pu","gaeng hanglay","moo krob","hoi tod","pad Thai","tom kha","kuay teow reua","laab","massaman"],
    "Korean":["ganjang gejang","bossam","naengmyeon","galbi jjim","yukhoe","kimchi jjigae","haemul pajeon","ssam platter","tteokbokki","budae jjigae"],
    "Indian":["nihari","biryani","kadhi pakora","galouti kebab","malai kofta","dal makhani","keema naan","butter chicken","pani puri","rogan josh","hariyali chicken","prawn balchão"],
    "Chinese":["mapo tofu","xiaolongbao","cumin lamb","dan dan mian","Peking duck","ma la pot","char siu","hand-pulled noodles","crispy duck pancakes","Sichuan dumplings"],
    "Spanish":["jamón ibérico","paella valenciana","pulpo a la gallega","croquetas","tortilla española","pan con tomate","patatas bravas","chorizo al vino","gambas al ajillo","arroz negro"],
    "Levantine":["msakhan","kibbeh nayyeh","muhammara","fattet","knafeh","baba ghanoush","hummus with lamb","labneh with za'atar","shakshuka","lamb mandi"],
    "Nordic":["langoustine tartare","burnt onion broth","cured reindeer","cloudberry","rye sourdough","smoked mackerel","pickled herring","potato waffle","birch sap sorbet","charred leek"],
    "Turkish":["mangal lamb","lahmacun","pide","iskender","kısır","borek","manti","kuzu tandır","çiğ köfte","imam bayıldı"],
    "Portuguese":["bacalhau à brás","sardinhas","piri-piri chicken","pastéis de nata","arroz de marisco","polvo à lagareiro","francesinha","caldo verde","cozido à portuguesa","açorda"],
    "Vietnamese":["bún chả","cá kho tộ","bánh xèo","chả cá","phở bò","bún bò Huế","gỏi cuốn","cơm tấm","bánh mì","cao lầu"],
    "Pan-Asian":["hopper & sothi","black garlic pork","smoked tofu","Szechuan prawns","Singapore laksa","char kway teow","rendang","Hainan chicken","nasi lemak","pho gà"],
    "Ethiopian":["doro wat","kitfo","shiro","tibs","injera platter","yebeg wat","misir wat","gomen","ayib","tej-braised lamb"],
    "Steakhouse":["60-day ribeye","porterhouse 40oz","beef dripping chips","bone marrow","wedge salad","chateaubriand","tartare","onglet","ribeye on the bone","sticky toffee pudding"],
    "Seafood":["turbot meunière","crab on toast","Dover sole","grilled brill","dressed crab","potted shrimp","native oysters","grilled langoustines","fish pie","smoked haddock"],
    "Bistro":["steak frites","escargot","frisée aux lardons","tartare","mousse au chocolat","pork rillettes","duck rillettes","crispy pig's head","hanger steak","tarte au citron"],
    "Natural Wine":["pet-nat","amphora white","pinot noir carbonic","fennel salad","ember leek","charred sourdough","gnarly parsnip","raw Orkney scallop","aged cheddar & pet-nat","fire-roast mushroom"]
  };
  const arr = dishes[cuisine] || ["chef's tasting"];
  return arr[Math.floor(rng() * arr.length)];
}

window.DAYDINE_DATA = buildData();
window.DAYDINE_META = {
  period: "Spring 2026",
  previousPeriod: "Winter 2025",
  updated: "2026-04-18",
  totalTracked: 4280,
  methodology: "A composite of critic reviews, reservation velocity, repeat-visit rate, and peer rank. See our Methodology."
};
